module.exports = {
    key : process.env.JWT
}